<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ems";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$ban = $_POST['ban'];
$bank_name = $_POST['bank_name'];
$ifsc = $_POST['ifsc'];
$empname = $_POST['empname'];
$created = date('Y-m-d H:i:s');

$sql = "INSERT INTO payroll_ban(bank_name, ifsc, empname, ban, created, status, status1)
 VALUES ('$bank_name', '$ifsc', '$empname', '$ban' , '$created', '1', '0')";

if ($conn->query($sql) === TRUE) {
    echo "Bank details added successfully!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();

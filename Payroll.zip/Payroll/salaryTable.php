<?php

$con = mysqli_connect("localhost", "root", "", "ems");

session_start();

if (!isset($_SESSION['user_name']) && !isset($_SESSION['name'])) {
  header('location:loginpage.php');
}
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="initial-scale=1, width=device-width" />

  <link rel="stylesheet" href="./css/global.css" />
  <link rel="stylesheet" href="./css/attendence.css" />
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600&display=swap" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.css" rel="stylesheet" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.js"></script>
  <style>
    .udbtn:hover {
      color: black !important;
      background-color: white !important;
      outline: 1px solid #F46114;
    }
  </style>
</head>

<body>
  <div class="attendence4">
    <div class="bg14"></div>
    <div class="rectangle-parent23" style="margin-top: -60px;">
      <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
        <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
          <tr>
            <th scope="col" class="px-6 py-3">
            </th>
            <th scope="col" class="px-6 py-3">
              Employee Name
            </th>
            <th scope="col" class="px-6 py-3">
              Gross Salary
            </th>
            <th scope="col" class="px-6 py-3">
              Basic Pay
            </th>
            <th scope="col" class="px-6 py-3">
              HRA
            </th>
            <th scope="col" class="px-6 py-3">
              Other Allowances
            </th>
            <th scope="col" class="px-6 py-3">
              EPF
            </th>
            <th scope="col" class="px-6 py-3">
              ESI
            </th>
            <th scope="col" class="px-6 py-3">
              Pension(Employer Share)
            </th>
            <th scope="col" class="px-6 py-3">
              EPF(Employer Share)
            </th>
            <th scope="col" class="px-6 py-3">
              ESI(Employer Share)
            </th>
            <th scope="col" class="px-6 py-3">
              Basic Pay after deduction
            </th>
            <th scope="col" class="px-6 py-3">
              Created
            </th>
          </tr>
        </thead>
        <?php
        $sql = "SELECT p.*, emp.pic 
        FROM payroll_msalarystruc AS p
        JOIN emp ON p.empname = emp.empname
        ORDER BY p.emp_no ASC;
        ";
        $que = mysqli_query($con, $sql);
        $cnt = 1;
        while ($result = mysqli_fetch_assoc($que)) {
        ?>
          <tbody>
            <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
              <td class="py-4"><img src="pics/<?php echo $result['pic']; ?>" style="border-radius: 50%; height: 30px; width: 100px;" alt=""></td>
              <td class="px-6 py-4">
                <?php echo $result['empname']; ?>
              </td>
              <td class="px-6 py-4">
                <?php echo $result['gs']; ?>
              </td>
              <td class="px-6 py-4">
                <?php echo $result['bbp']; ?>
              </td>
              <td class="px-6 py-4">
                <?php echo $result['hra']; ?>
              </td>
              <td class="px-6 py-4">
                <?php echo $result['oa']; ?>
              </td>
              <td class="px-6 py-4">
                <?php echo $result['epf1']; ?>
              </td>
              <td class="px-6 py-4">
                <?php echo $result['esi1']; ?>
              </td>
              <td class="px-6 py-4">
                <?php echo $result['epf2']; ?>
              </td>
              <td class="px-6 py-4">
                <?php echo $result['epf3']; ?>
              </td>
              <td class="px-6 py-4">
                <?php echo $result['esi2']; ?>
              </td>
              <td class="px-6 py-4">
                <?php echo $result['abp']; ?>
              </td>
              <td class="px-6 py-4">
                <?php echo $result['created']; ?>
              </td>
            </tr>
          <?php $cnt++;
        } ?>
          </tbody>
      </table>
    </div>
    <img class="attendence-child" alt="" src="./public/rectangle-1@2x.png" />

    <img class="attendence-item" alt="" src="./public/rectangle-2@2x.png" />

    <img class="logo-1-icon14" alt="" src="./public/logo-1@2x.png" />
    <a class="anikahrm14" href="./index.html" id="anikaHRM">
      <span>Anika</span>
      <span class="hrm14">HRM</span>
    </a>
    <a class="attendence-management4" href="./index.html" id="attendenceManagement">Payroll Management</a>
    <button class="attendence-inner"></button>
    <div class="logout14">Logout</div>
    <a href="./payroll.html" class="payroll14" style="color: white; z-index:9999;">Payroll</a>
    <a class="reports14">Reports</a>
    <img class="uitcalender-icon14" alt="" src="./public/uitcalender.svg" />

    <img style="-webkit-filter: grayscale(1) invert(1);
      filter: grayscale(1) invert(1); z-index:9999;" class="arcticonsgoogle-pay14" alt="" src="./public/arcticonsgooglepay.svg" />

    <img class="streamlineinterface-content-c-icon14" alt="" src="./public/streamlineinterfacecontentchartproductdataanalysisanalyticsgraphlinebusinessboardchart.svg" />

    <img class="attendence-child1" alt="" src="./public/ellipse-1@2x.png" />

    <img class="material-symbolsperson-icon14" alt="" src="./public/materialsymbolsperson.svg" />

    <img class="attendence-child2" alt="" style="margin-top: 66px;" src="./public/rectangle-4@2x.png" />

    <a class="dashboard14" href="./index.php" id="dashboard">Dashboard</a>
    <a class="fluentpeople-32-regular14" id="fluentpeople32Regular">
      <img class="vector-icon73" alt="" src="./public/vector7.svg" />
    </a>
    <a class="employee-list14" href="employee-management.php" id="employeeList">Employee List</a>
    <a class="akar-iconsdashboard14" href="./index.php" id="akarIconsdashboard">
      <img class="vector-icon74" alt="" src="./public/vector3.svg" />
    </a>
    <img class="tablerlogout-icon14" alt="" src="./public/tablerlogout.svg" />

    <a class="leaves14" id="leaves" href="leave-management.php">Leaves</a>
    <a class="fluentperson-clock-20-regular14" id="fluentpersonClock20Regular">
      <img class="vector-icon75" alt="" src="./public/vector1.svg" />
    </a>
    <a class="onboarding16" id="onboarding" href="onboarding.php">Onboarding</a>
    <a class="fluent-mdl2leave-user14" id="fluentMdl2leaveUser">
      <img class="vector-icon76" alt="" src="./public/vector.svg" />
    </a>
    <a class="attendance14" href="attendence.php" style="color: black;">Attendance</a>
    <a class="uitcalender14">
      <img class="vector-icon77" style="-webkit-filter: grayscale(1) invert(1);
        filter: grayscale(1) invert(1);" alt="" src="./public/vector11.svg" />
    </a>
    <div class="oouinext-ltr3"></div>
  </div>
</body>

</html>
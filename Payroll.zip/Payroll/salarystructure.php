<?php

$con = mysqli_connect("localhost", "root", "", "ems");

session_start();

if (!isset($_SESSION['user_name']) && !isset($_SESSION['name'])) {
    header('location:loginpage.php');
}
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="initial-scale=1, width=device-width" />

    <link rel="stylesheet" href="./css/global.css" />
    <link rel="stylesheet" href="./css/attendence.css" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600&display=swap" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.css" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css" integrity="sha512-NhSC1YmyruXifcj/KFRWoC561YpHpc5Jtzgvbuzx5VozKpWvQ+4nXhPdFgmx8xqexRcpAglTj9sIBWINXa8x5w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.css" integrity="sha512-oHDEc8Xed4hiW6CxD7qjbnI+B07vDdX7hEPTvn9pSZO1bcRqHp8mj9pyr+8RVC2GmtEfI2Bi9Ke9Ass0as+zpg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        .udbtn:hover {
            color: black !important;
            background-color: white !important;
            outline: 1px solid #F46114;
        }

        .rectangle-div {
            position: absolute;
            /* top: 136px; */
            border-radius: 20px;
            background-color: var(--color-white);
            width: 675px;
            height: 770px;
        }
    </style>
</head>

<body>
    <div class="attendence4">
        <div class="bg14"></div>
        <div class="rectangle-parent23" style="margin-top: -90px;">
            <!-- Emp details -->
            <form id="updateForm">
                <div>
                    <div style="display: flex; gap: 10px;">
                        <p style="margin-left: 20px; margin-top: 10px;">Employee Details:</p>
                        <div>
                            <select name="empname" onchange="getEmployeeDetails(this.value)" style="font-size: 18px; width: 300px; height: 40px; margin-left: 20px; border-radius: 5px;">
                                <option value="" style="font-weight: lighter;">Select Employee Name</option>
                                <?php
                                $servername = "localhost";
                                $username = "root";
                                $password = "";
                                $dbname = "ems";

                                $conn = new mysqli($servername, $username, $password, $dbname);

                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }

                                $sql = "SELECT empname FROM emp where empstatus=0 ORDER BY emp_no ASC";
                                $result = $conn->query($sql);

                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        echo "<option value='" . $row["empname"] . "'>" . $row["empname"] . "</option>";
                                    }
                                } else {
                                    echo "0 results";
                                }

                                $conn->close();
                                ?>
                            </select>
                        </div>
                        <div>
                            <input name="emp_no" type="text" id="emp_no" style="font-size: 18px; width: 300px; height: 40px; margin-left: 20px; border-radius: 5px;" placeholder="Employee ID" readonly>
                        </div>
                        <div>
                            <input name="desg" type="text" id="desg" style="font-size: 18px; width: 300px; height: 40px; margin-left: 20px; border-radius: 5px;" placeholder="Designation" readonly>
                        </div>
                    </div>
                </div><br>
                <div class="rectangle-div"></div>
                <div>
                    <div style="position: absolute; top: 50px;">
                        <p style="text-align: center; font-size: 25px; padding-top: 20px;">Monthly Component</p>
                        <hr style="width: 103%;" />

                        <!-- Salary Details -->

                        <div>
                            <p style="margin-left: 20px; margin-top: 10px;">Salary Details:</p>
                            <img src="./public/infosym.png" width="20px" alt="" style="margin-left: 160px; margin-top: -20px;">
                            <div style="display: flex; margin-top: 10px;">
                                <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">Gross Salary (CTC):</label>
                                <div style="display: flex; margin-left: 20px;">
                                    <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                    <input type="text" name="gs" id="gs" oninput="calculateAGS(); " style="font-size: 18px; width: 300px; height: 40px; border: 1px solid rgb(185,185,185);">
                                    <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                </div>
                            </div>
                            <div style="display: flex; margin-top: 10px;">
                                <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">Basic Pay:</label>
                                <div style="display: flex; margin-left: 86px;">
                                    <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                    <input type="text" name="bbp" id="bbp" oninput="calculateABBP();" style="font-size: 18px; width: 300px; height: 40px; border: 1px solid rgb(185,185,185);">
                                    <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                </div>
                            </div>
                            <div style="display: flex; margin-top: 10px;">
                                <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">HRA:</label>
                                <div style="display: flex; margin-left: 130px;">
                                    <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                    <input type="text" name="hra" id="hra" oninput="calculateAHRA(); calculatesumNet(); " style="font-size: 18px; width: 300px; height: 40px; border: 1px solid rgb(185,185,185);">
                                    <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                </div>
                            </div>
                            <div style="display: flex; margin-top: 10px;">
                                <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">Other Allowances:</label>
                                <div style="display: flex; margin-left: 25px;">
                                    <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                    <input type="text" name="oa" id="oa" oninput="calculateAOA(); calculatesumNet(); " style="font-size: 18px; width: 300px; height: 40px; border: 1px solid rgb(185,185,185);">
                                    <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                </div>
                            </div>

                        </div>
                        <!-- Deductions on Basic pay -->
                        <div>
                            <p style="margin-left: 20px; margin-top: 10px;">Deductions on Basic pay:</p>
                            <img src="./public/infosym.png" width="20px" alt="" style="margin-left: 260px; margin-top: -20px;">
                            <div style="display: flex; margin-top: 10px;">
                                <div style="display: flex;">
                                    <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">EPF:</label>
                                    <div style="display: flex; margin-left: 40px;">
                                        <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                        <input type="text" name="epf1" id="epf1" oninput="calculateAEPF1(); calculatesumDeduc();" style="font-size: 18px; width: 150px; height: 40px; border: 1px solid rgb(185,185,185);">
                                        <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                    </div>
                                </div>
                                <div style="display: flex;">
                                    <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">ESI:</label>
                                    <div style="display: flex; margin-left: 70px;">
                                        <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                        <input type="text" name="esi1" id="esi1" oninput="calculateAESI1(); calculatesumDeduc();" style="font-size: 18px; width: 150px; height: 40px; border: 1px solid rgb(185,185,185);">
                                        <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                    </div>
                                </div>
                            </div>
                            <!-- <p style="margin-left: 20px; font-weight: lighter; font-size: 15px; margin-top: 10px; color: #F46114;">ESI deductions applicable only if gross salary is more than 21000</p> -->
                        </div>
                        <!-- Employer share EPF -->
                        <div>
                            <p style="margin-left: 20px; margin-top: 10px;">Employer Share on EPF:</p>
                            <img src="./public/infosym.png" width="20px" alt="" style="margin-left: 250px; margin-top: -20px;">
                            <div style="display: flex; margin-top: 10px;">
                                <div style="display: flex;">
                                    <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">Pension:</label>
                                    <div style="display: flex; margin-left: 10px;">
                                        <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                        <input type="text" name="epf2" id="epf2" oninput="calculateAEPF2(); calculatesumEmployer();" style="font-size: 18px; width: 150px; height: 40px; border: 1px solid rgb(185,185,185);">
                                        <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                    </div>
                                </div>
                                <div style="display: flex;">
                                    <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">EPF Share:</label>
                                    <div style="display: flex; margin-left: 10px;">
                                        <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                        <input type="text" name="epf3" id="epf3" oninput="calculateAEPF3(); calculatesumEmployer();" style="font-size: 18px; width: 150px; height: 40px; border: 1px solid rgb(185,185,185);">
                                        <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                    </div>
                                </div>
                            </div>
                            <!-- <p style="margin-left: 20px; font-weight: lighter; font-size: 15px; margin-top: 10px; color: #F46114;">Total Employer share on EPF is 12%</p> -->
                        </div>
                        <!-- Employer share ESI -->
                        <div>
                            <p style="margin-left: 20px; margin-top: 10px;">Employer Share on ESI:</p>
                            <img src="./public/infosym.png" width="20px" alt="" style="margin-left: 240px; margin-top: -20px;">
                            <div style="display: flex; margin-top: 10px;">
                                <div style="display: flex; margin-top: 10px;">
                                    <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">Employer Share:</label>
                                    <div style="display: flex; margin-left: 20px;">
                                        <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                        <input type="text" name="esi2" id="esi2" oninput="calculateAESI2(); calculatesumEmployer();" style="font-size: 18px; width: 300px; height: 40px; border: 1px solid rgb(185,185,185);">
                                        <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Basicpay after deductions -->
                        <div>
                            <p style="margin-left: 20px; margin-top: 10px;">Basic pay after deductions:</p>
                            <img src="./public/infosym.png" width="20px" alt="" style="margin-left: 280px; margin-top: -20px;">
                            <div style="display: flex; margin-top: 10px;">
                                <div style="display: flex; margin-top: 10px;">
                                    <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">Basic Pay:</label>
                                    <div style="display: flex; margin-left: 67px;">
                                        <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                        <input type="text" name="abp" id="abp" oninput="calculateAABP(); calculatesumNet();" style="font-size: 18px; width: 300px; height: 40px; border: 1px solid rgb(185,185,185);">
                                        <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                    </div>
                                </div>
                            </div>
                        </div><br>
                        <!-- Cross calc -->
                        <hr style="width: 103%;">
                        <div>
                            <div style="display: flex; margin-top: 10px;">
                                <div style="display: flex;">
                                    <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">CTC Calc:</label>
                                    <div style="display: flex; margin-left: 10px;">
                                        <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                        <input type="text" name="ctc" id="ctc" oninput="calculateACTC();" style="font-size: 18px; width: 150px; height: 40px; border: 1px solid rgb(185,185,185);">
                                        <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                    </div>
                                </div>
                                <div style="display: flex;">
                                    <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">Total Deductions:</label>
                                    <div style="display: flex; margin-left: 10px;">
                                        <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                        <input type="text" name="tde" id="tde" oninput="calculateATDE();" style="font-size: 18px; width: 120px; height: 40px; border: 1px solid rgb(185,185,185);">
                                        <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                    </div>
                                </div>
                            </div>
                            <div style="display: flex; margin-top: 10px;">
                                <div style="display: flex;">
                                    <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">NET Pay:</label>
                                    <div style="display: flex; margin-left: 15px;">
                                        <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                        <input type="text" name="netpay" id="netpay" oninput="calculateANETPAY();" style="font-size: 18px; width: 150px; height: 40px; border: 1px solid rgb(185,185,185);">
                                        <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                    </div>
                                </div>
                                <div style="display: flex;">
                                    <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">Employer Share:</label>
                                    <div style="display: flex; margin-left: 18px;">
                                        <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                        <input type="text" name="tes" id="tes" oninput="calculateATES();" style="font-size: 18px; width: 120px; height: 40px; border: 1px solid rgb(185,185,185);">
                                        <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                    </div>
                                </div>
                            </div>
                            <!-- <p style="margin-left: 20px; font-weight: lighter; font-size: 15px; margin-top: 10px; color: #F46114;">Total Employer share on EPF is 12%</p> -->
                        </div>
                    </div>
                </div>
                <!-- annual Component -->
                <div class="rectangle-div" style="margin-left: 700px;"></div>
                <div>
                    <div style="position: absolute; top: 50px; margin-left: 700px;">
                        <p style="text-align: center; font-size: 25px; padding-top: 20px;">Annual Component</p>
                        <hr style="width: 103%;" />
                        <!-- Salary Details -->
                        <div>
                            <p style="margin-left: 20px; margin-top: 10px;">Salary Details:</p>
                            <img src="./public/infosym.png" width="20px" alt="" style="margin-left: 160px; margin-top: -20px;">
                            <div style="display: flex; margin-top: 10px;">
                                <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">Gross Salary (CTC):</label>
                                <div style="display: flex; margin-left: 20px;">
                                    <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                    <input name="ags" id="ags" type="text" style="font-size: 18px; width: 300px; height: 40px; border: 1px solid rgb(185,185,185);">
                                    <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                </div>
                            </div>
                            <div style="display: flex; margin-top: 10px;">
                                <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">Basic Pay:</label>
                                <div style="display: flex; margin-left: 86px;">
                                    <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                    <input name="abbp" id="abbp" type="text" style="font-size: 18px; width: 300px; height: 40px; border: 1px solid rgb(185,185,185);">
                                    <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                </div>
                            </div>
                            <div style="display: flex; margin-top: 10px;">
                                <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">HRA:</label>
                                <div style="display: flex; margin-left: 130px;">
                                    <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                    <input name="ahra" id="ahra" type="text" style="font-size: 18px; width: 300px; height: 40px; border: 1px solid rgb(185,185,185);">
                                    <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                </div>
                            </div>
                            <div style="display: flex; margin-top: 10px;">
                                <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">Other Allowances:</label>
                                <div style="display: flex; margin-left: 25px;">
                                    <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                    <input name="aoa" id="aoa" type="text" style="font-size: 18px; width: 300px; height: 40px; border: 1px solid rgb(185,185,185);">
                                    <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                </div>
                            </div>

                        </div>
                        <!-- Deductions on Basic pay -->
                        <div>
                            <p style="margin-left: 20px; margin-top: 10px;">Deductions on Basic pay:</p>
                            <img src="./public/infosym.png" width="20px" alt="" style="margin-left: 260px; margin-top: -20px;">
                            <div style="display: flex; margin-top: 10px;">
                                <div style="display: flex;">
                                    <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">EPF:</label>
                                    <div style="display: flex; margin-left: 40px;">
                                        <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                        <input name="aepf1" id="aepf1" type="text" style="font-size: 18px; width: 150px; height: 40px; border: 1px solid rgb(185,185,185);">
                                        <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                    </div>
                                </div>
                                <div style="display: flex;">
                                    <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">ESI:</label>
                                    <div style="display: flex; margin-left: 70px;">
                                        <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                        <input type="text" name="aesi1" id="aesi1" style="font-size: 18px; width: 150px; height: 40px; border: 1px solid rgb(185,185,185);">
                                        <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                    </div>
                                </div>
                            </div>
                            <!-- <p style="margin-left: 20px; font-weight: lighter; font-size: 15px; margin-top: 10px; color: #F46114;">ESI deductions applicable only if gross salary is more than 21000</p> -->
                        </div>
                        <!-- Employer share EPF -->
                        <div>
                            <p style="margin-left: 20px; margin-top: 10px;">Employer Share on EPF:</p>
                            <img src="./public/infosym.png" width="20px" alt="" style="margin-left: 250px; margin-top: -20px;">
                            <div style="display: flex; margin-top: 10px;">
                                <div style="display: flex;">
                                    <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">Pension:</label>
                                    <div style="display: flex; margin-left: 10px;">
                                        <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                        <input type="text" name="aepf2" id="aepf2" style="font-size: 18px; width: 150px; height: 40px; border: 1px solid rgb(185,185,185);">
                                        <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                    </div>
                                </div>
                                <div style="display: flex;">
                                    <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">EPF Share:</label>
                                    <div style="display: flex; margin-left: 10px;">
                                        <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                        <input type="text" name="aepf3" id="aepf3" style="font-size: 18px; width: 150px; height: 40px; border: 1px solid rgb(185,185,185);">
                                        <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                    </div>
                                </div>
                            </div>
                            <!-- <p style="margin-left: 20px; font-weight: lighter; font-size: 15px; margin-top: 10px; color: #F46114;">Total Employer share on EPF is 12%</p> -->
                        </div>
                        <!-- Employer share ESI -->
                        <div>
                            <p style="margin-left: 20px; margin-top: 10px;">Employer Share on ESI:</p>
                            <img src="./public/infosym.png" width="20px" alt="" style="margin-left: 240px; margin-top: -20px;">
                            <div style="display: flex; margin-top: 10px;">
                                <div style="display: flex; margin-top: 10px;">
                                    <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">Employer Share:</label>
                                    <div style="display: flex; margin-left: 20px;">
                                        <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                        <input type="text" name="aesi2" id="aesi2" style="font-size: 18px; width: 300px; height: 40px; border: 1px solid rgb(185,185,185);">
                                        <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Basicpay after deductions -->
                        <div>
                            <p style="margin-left: 20px; margin-top: 10px;">Basic pay after deductions:</p>
                            <img src="./public/infosym.png" width="20px" alt="" style="margin-left: 280px; margin-top: -20px;">
                            <div style="display: flex; margin-top: 10px;">
                                <div style="display: flex; margin-top: 10px;">
                                    <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">Basic Pay:</label>
                                    <div style="display: flex; margin-left: 67px;">
                                        <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                        <input type="text" name="aabp" id="aabp" style="font-size: 18px; width: 300px; height: 40px; border: 1px solid rgb(185,185,185);">
                                        <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                    </div>
                                </div>
                            </div>
                        </div><br>
                        <!-- Cross calc -->
                        <hr style="width: 103%;">
                        <div>
                            <div style="display: flex; margin-top: 10px;">
                                <div style="display: flex;">
                                    <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">CTC Calc:</label>
                                    <div style="display: flex; margin-left: 10px;">
                                        <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                        <input type="text" name="actc" id ="actc" style="font-size: 18px; width: 150px; height: 40px; border: 1px solid rgb(185,185,185);">
                                        <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                    </div>
                                </div>
                                <div style="display: flex;">
                                    <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">Total Deductions:</label>
                                    <div style="display: flex; margin-left: 10px;">
                                        <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                        <input type="text" name="atde" id="atde" style="font-size: 18px; width: 120px; height: 40px; border: 1px solid rgb(185,185,185);">
                                        <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                    </div>
                                </div>
                            </div>
                            <div style="display: flex; margin-top: 10px;">
                                <div style="display: flex;">
                                    <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">NET Pay:</label>
                                    <div style="display: flex; margin-left: 15px;">
                                        <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                        <input type="text" name="anetpay" id="anetpay" style="font-size: 18px; width: 150px; height: 40px; border: 1px solid rgb(185,185,185);">
                                        <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                    </div>
                                </div>
                                <div style="display: flex;">
                                    <label for="" style="font-weight: lighter; margin-top: 10px; font-size: 18px; margin-left: 20px;">Employer Share:</label>
                                    <div style="display: flex; margin-left: 18px;">
                                        <div style="display: flex; border: 1px solid rgb(185,185,185); width: 30px; align-items: center; justify-content: center; background-color: rgb(240, 240, 240); border-top-left-radius: 10px; border-bottom-left-radius: 10px;">₹</div>
                                        <input type="text" name="ates" id="ates" style="font-size: 18px; width: 120px; height: 40px; border: 1px solid rgb(185,185,185);">
                                        <div style="display: flex; width: 30px; align-items: center; border: 1px solid rgb(185,185,185); justify-content: center; background-color: rgb(240, 240, 240); border-top-right-radius: 10px; border-bottom-right-radius: 10px;">/-</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <button type="submit" class="udbtn" style="background-color: #FB8A0B; color: white; border: none; border-radius: 5px; width: 150px; height: 50px; font-size: 22px; margin-left: 610px; margin-top: 780px;">Submit</button>
        </div>
        </form>
        <img class="attendence-child" alt="" src="./public/rectangle-1@2x.png" />

        <img class="attendence-item" alt="" src="./public/rectangle-2@2x.png" />

        <img class="logo-1-icon14" alt="" src="./public/logo-1@2x.png" />
        <a class="anikahrm14" href="./index.html" id="anikaHRM">
            <span>Anika</span>
            <span class="hrm14">HRM</span>
        </a>
        <a class="attendence-management4" href="./index.html" id="attendenceManagement">Payroll Management</a>
        <button class="attendence-inner"></button>
        <div class="logout14">Logout</div>
        <a href="./payroll.html" class="payroll14" style="color: white; z-index:9999;">Payroll</a>
        <a class="reports14">Reports</a>
        <img class="uitcalender-icon14" alt="" src="./public/uitcalender.svg" />

        <img style="-webkit-filter: grayscale(1) invert(1);
      filter: grayscale(1) invert(1); z-index:9999;" class="arcticonsgoogle-pay14" alt="" src="./public/arcticonsgooglepay.svg" />

        <img class="streamlineinterface-content-c-icon14" alt="" src="./public/streamlineinterfacecontentchartproductdataanalysisanalyticsgraphlinebusinessboardchart.svg" />

        <img class="attendence-child1" alt="" src="./public/ellipse-1@2x.png" />

        <img class="material-symbolsperson-icon14" alt="" src="./public/materialsymbolsperson.svg" />

        <img class="attendence-child2" alt="" style="margin-top: 66px;" src="./public/rectangle-4@2x.png" />

        <a class="dashboard14" href="./index.php" id="dashboard">Dashboard</a>
        <a class="fluentpeople-32-regular14" id="fluentpeople32Regular">
            <img class="vector-icon73" alt="" src="./public/vector7.svg" />
        </a>
        <a class="employee-list14" href="employee-management.php" id="employeeList">Employee List</a>
        <a class="akar-iconsdashboard14" href="./index.php" id="akarIconsdashboard">
            <img class="vector-icon74" alt="" src="./public/vector3.svg" />
        </a>
        <img class="tablerlogout-icon14" alt="" src="./public/tablerlogout.svg" />

        <a class="leaves14" id="leaves" href="leave-management.php">Leaves</a>
        <a class="fluentperson-clock-20-regular14" id="fluentpersonClock20Regular">
            <img class="vector-icon75" alt="" src="./public/vector1.svg" />
        </a>
        <a class="onboarding16" id="onboarding" href="onboarding.php">Onboarding</a>
        <a class="fluent-mdl2leave-user14" id="fluentMdl2leaveUser">
            <img class="vector-icon76" alt="" src="./public/vector.svg" />
        </a>
        <a class="attendance14" href="attendence.php" style="color: black;">Attendance</a>
        <a class="uitcalender14">
            <img class="vector-icon77" style="-webkit-filter: grayscale(1) invert(1);
        filter: grayscale(1) invert(1);" alt="" src="./public/vector11.svg" />
        </a>
        <div class="oouinext-ltr3"></div>
    </div>
    <script>
        function calculateAGS() {
            var gsValue = document.getElementById("gs").value;
            var agsValue = parseFloat(gsValue) * 12;
            document.getElementById("ags").value = agsValue;
        }

        function calculateABBP() {
            var gsValue = document.getElementById("bbp").value;
            var agsValue = parseFloat(gsValue) * 12;
            document.getElementById("abbp").value = agsValue;
        }

        function calculateAHRA() {
            var gsValue = document.getElementById("hra").value;
            var agsValue = parseFloat(gsValue) * 12;
            document.getElementById("ahra").value = agsValue;
        }

        function calculateAOA() {
            var gsValue = document.getElementById("oa").value;
            var agsValue = parseFloat(gsValue) * 12;
            document.getElementById("aoa").value = agsValue;
        }

        function calculateAEPF1() {
            var gsValue = document.getElementById("epf1").value;
            var agsValue = parseFloat(gsValue) * 12;
            document.getElementById("aepf1").value = agsValue;
        }

        function calculateAESI1() {
            var gsValue = document.getElementById("esi1").value;
            var agsValue = parseFloat(gsValue) * 12;
            document.getElementById("aesi1").value = agsValue;
        }

        function calculateAEPF2() {
            var gsValue = document.getElementById("epf2").value;
            var agsValue = parseFloat(gsValue) * 12;
            document.getElementById("aepf2").value = agsValue;
        }

        function calculateAEPF3() {
            var gsValue = document.getElementById("epf3").value;
            var agsValue = parseFloat(gsValue) * 12;
            document.getElementById("aepf3").value = agsValue;
        }

        function calculateAESI2() {
            var gsValue = document.getElementById("esi2").value;
            var agsValue = parseFloat(gsValue) * 12;
            document.getElementById("aesi2").value = agsValue;
        }

        function calculateAABP() {
            var gsValue = document.getElementById("abp").value;
            var agsValue = parseFloat(gsValue) * 12;
            document.getElementById("aabp").value = agsValue;
        }

        function calculateACTC() {
            var gsValue = document.getElementById("ctc").value;
            var agsValue = parseFloat(gsValue) * 12;
            document.getElementById("actc").value = agsValue;
        }
        function calculateANETPAY() {
            var gsValue = document.getElementById("netpay").value;
            var agsValue = parseFloat(gsValue) * 12;
            document.getElementById("anetpay").value = agsValue;
        }
        function calculateATDE() {
            var gsValue = document.getElementById("tde").value;
            var agsValue = parseFloat(gsValue) * 12;
            document.getElementById("atde").value = agsValue;
        }
        function calculateATES() {
            var gsValue = document.getElementById("tes").value;
            var agsValue = parseFloat(gsValue) * 12;
            document.getElementById("ates").value = agsValue;
        }
    </script>
    <script>
        function calculatesumNet() {
            var abpValue = parseFloat(document.getElementById("abp").value) || 0;
            var hraValue = parseFloat(document.getElementById("hra").value) || 0;
            var oaValue = parseFloat(document.getElementById("oa").value) || 0;

            var sum = abpValue + hraValue + oaValue;
            document.getElementById("netpay").value = sum;
            calculateCTC(); 
            calculateANETPAY();
        }
        function calculatesumDeduc() {
            var epf1Value = parseFloat(document.getElementById("epf1").value) || 0;
            var esi1Value = parseFloat(document.getElementById("esi1").value) || 0;

            var sum = epf1Value + esi1Value;
            document.getElementById("tde").value = sum;
            calculateCTC(); 
            calculateATDE();
        }
        function calculatesumEmployer() {
            var epf2Value = parseFloat(document.getElementById("epf2").value) || 0;
            var epf3Value = parseFloat(document.getElementById("epf3").value) || 0;
            var esi2Value = parseFloat(document.getElementById("esi2").value) || 0;

            var sum = epf2Value + epf3Value + esi2Value;
            document.getElementById("tes").value = sum;
            calculateCTC(); 
            calculateATES();
        }
        function calculateCTC() {
        var abpValue = parseFloat(document.getElementById("abp").value) || 0;
        var hraValue = parseFloat(document.getElementById("hra").value) || 0;
        var oaValue = parseFloat(document.getElementById("oa").value) || 0;
        var epf1Value = parseFloat(document.getElementById("epf1").value) || 0;
        var esi1Value = parseFloat(document.getElementById("esi1").value) || 0;
        var epf2Value = parseFloat(document.getElementById("epf2").value) || 0;
        var epf3Value = parseFloat(document.getElementById("epf3").value) || 0;
        var esi2Value = parseFloat(document.getElementById("esi2").value) || 0;

        var tsum = abpValue + hraValue + oaValue + epf2Value + epf1Value + esi1Value + epf3Value + esi2Value;
        document.getElementById("ctc").value = tsum;
        calculateACTC();
    }
    </script>
    <script>
        function getEmployeeDetails(empname) {
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    var response = JSON.parse(this.responseText);
                    document.getElementById("emp_no").value = response.emp_no;
                    document.getElementById("desg").value = response.desg;
                }
            };
            xhttp.open("GET", "get_employee_details.php?empname=" + empname, true);
            xhttp.send();
        }
    </script>
    <script>
        $(document).ready(function() {
            $("#updateForm").submit(function(e) {
                e.preventDefault();
                var formData = new FormData(this);

                $.ajax({
                    type: "POST",
                    url: "insert_msalarystruc.php",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Added!',
                            text: response,
                            confirmButtonText: 'OK'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                window.location.href = 'salarystructure.php';
                            }
                        });
                    }
                });

                $.ajax({
                    type: "POST",
                    url: "insert_asalarystruc.php",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Added!',
                            text: response,
                            confirmButtonText: 'OK'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                window.location.href = 'salarystructure.php';
                            }
                        });
                    }
                });
            });
        });
    </script>

</body>

</html>